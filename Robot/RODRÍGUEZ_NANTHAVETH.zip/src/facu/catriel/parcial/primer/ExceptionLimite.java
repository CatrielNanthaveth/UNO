package facu.catriel.parcial.primer;

public class ExceptionLimite extends Exception {

	public ExceptionLimite(String msg) {
		super(msg);
	}
}
